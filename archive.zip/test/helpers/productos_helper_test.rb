require 'test_helper'

class ProductosHelperTest < ActionView::TestCase
end
